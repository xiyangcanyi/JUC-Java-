package com.atguigu.zyp.blockqueue;

import java.sql.Time;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @author zyp
 * @create 2023-02-16 13:49
 */
public class Test {
    public static void main(String[] args) {
//        test1();
//        test2();
//        try {
//            test3();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        try {
            test4();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    /*
     * 抛出异常
     * */
    public static void test1(){
//        队列的大小
        ArrayBlockingQueue blockingQueue = new ArrayBlockingQueue<>(3);

        System.out.println(blockingQueue.add("a"));
        System.out.println(blockingQueue.add("b"));
        System.out.println(blockingQueue.add("c"));

//        队列已满被阻塞 IllegalStateException: Queue full 抛出异常!
//        System.out.println(blockingQueue.add("d"));
//        查看队首元素是谁
        System.out.println(blockingQueue.element());//a

        System.out.println("+++++++++++++++++");
        System.out.println(blockingQueue.remove());
        System.out.println(blockingQueue.remove());
        System.out.println(blockingQueue.remove());

//  抛出异常 java.util.NoSuchElementException
//        System.out.println(blockingQueue.remove());




    }

    /*
    * 有返回值但是没有异常
    *
    * */

    public static void test2(){
        ArrayBlockingQueue blockingQueue=new ArrayBlockingQueue(3);
        System.out.println(blockingQueue.offer("a"));
        System.out.println(blockingQueue.offer("b"));
        System.out.println(blockingQueue.offer("c"));//true
//
        System.out.println(blockingQueue.offer("d"));//false:不抛出异常

//
        System.out.println(blockingQueue.peek());//a获取队首元素

        System.out.println("============================");
        System.out.println(blockingQueue.poll());
        System.out.println(blockingQueue.poll());
        System.out.println(blockingQueue.poll());//a,b,c

        System.out.println(blockingQueue.poll());//null 不报异常
    }
    /*
    * 等待，阻塞（等待超时）
    * */

    public static void test3() throws InterruptedException {
//        队列的大小
        ArrayBlockingQueue blockingQueue = new ArrayBlockingQueue<>(3);

//        一直阻塞
        blockingQueue.put("a");
        blockingQueue.put("b");
        blockingQueue.put("c");

//        blockingQueue.put("d");//队列没有位置(一直被阻塞等待)

        System.out.println(blockingQueue.take());
        System.out.println(blockingQueue.take());
        System.out.println(blockingQueue.take());

//        队列中没有元素了，一直等待，被阻塞
        System.out.println(blockingQueue.take());


    }


    /*
    * 超时等待
    * */
    public static void test4() throws InterruptedException {
        ArrayBlockingQueue blockingQueue = new ArrayBlockingQueue<>(3);

        blockingQueue.offer("a");
        blockingQueue.offer("b");
        blockingQueue.offer("c");
        System.out.println("=====添加三个元素===========");

//        blockingQueue.offer("d",3, TimeUnit.SECONDS);

        System.out.println(blockingQueue.poll());
        System.out.println(blockingQueue.poll());
        System.out.println(blockingQueue.poll());
        blockingQueue.poll(3, TimeUnit.SECONDS);//等待三秒就退出


    }
}
