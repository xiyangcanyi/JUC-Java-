package com.atguigu.zyp.single;

/**
 * @author zyp
 * @create 2023-02-17 11:46
 */

//静态内部类
public class Holder {
}
