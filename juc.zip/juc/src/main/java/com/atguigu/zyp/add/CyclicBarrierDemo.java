package com.atguigu.zyp.add;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

/**
 * @author zyp
 * @create 2023-02-16 11:38
 */
public class CyclicBarrierDemo {
    public static void main(String[] args) {
          /*
    及其七颗物品召唤另一个物品

     */
//        召唤每一个物品
        CyclicBarrier cyclicBarrier = new CyclicBarrier(8, ()->{
            System.out.println("召唤成功物品");

        });

        for (int i = 1; i <=7; i++) {
             final int temp=i;

//            lambda操作不到i变量
            new Thread(()->{
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread().getName()+"收集了"+temp+"个物品");
                try {
                    cyclicBarrier.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (BrokenBarrierException e) {
                    e.printStackTrace();
                }
            }).start();

        }

    }



}
