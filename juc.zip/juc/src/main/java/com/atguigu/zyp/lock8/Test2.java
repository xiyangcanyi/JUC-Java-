package com.atguigu.zyp.lock8;

import java.util.concurrent.TimeUnit;

/**
 * @author zyp
 * @create 2023-02-15 22:05
 *
 * 3、 增加了一个普通方法后！先执行发短信还是Hello？// 普通方法
 *  * 4、 两个对象，两个同步方法， 发短信还是 打电话？ // 打电话
 *  先执行打电话，接着执行hello，最后执行发短信
 */

public class Test2 {

    public static void main(String[] args) {
        // 两个对象，两个调用者，两把锁！锁不唯一
        Phone2 phone = new Phone2();
        Phone2 phone2 = new Phone2();
        new Thread(()->{
            phone2.sendSms();
        },"A").start();
//        发短信还是打电话（捕获）
        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        new Thread(()->{
            phone.call();
        }).start();

       new Thread(()->{
           phone.hello();
       },"C").start();


    }


}
class  Phone2{
    // synchronized 锁的对象是方法的调用者！、
    // 两个方法用的是同一个对象调用(同一个锁)，谁先拿到锁谁执行！
    public synchronized void sendSms(){
        try {
            TimeUnit.SECONDS.sleep(4);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("发短信");

    }
    public synchronized void call(){
        System.out.println("打电话");
    }


    // 这里没有锁！不是同步方法，不受锁的影响
    public void hello(){
        System.out.println("hello");
    }


}
