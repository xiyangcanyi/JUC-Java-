package com.atguigu.zyp.lock;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.ILoggerFactory;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

import static java.lang.Thread.sleep;


/**
 * @author zyp
 * @create 2023-02-17 16:49
 */
@Slf4j(topic = "c.AQSTest")
public class AQSTest {

    public static void main(String[] args) throws Exception{
        MyLock lock = new MyLock();

        new Thread(()->{
            lock.lock();
            try {
                log.debug("locking.....");
                sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
//                System.out.println("unlocking------");
                log.debug("unlocking--------------");
                lock.unlock();
            }
        },"T1").start();
        new Thread(()->{
            lock.lock();
            try {
                log.debug("locking.....");
            } finally {
//                System.out.println("unlocking------");
                log.debug("unlocking--------------");
                lock.unlock();
            }
        },"T1").start();

        new Thread(()->{}).start();

    }
}


//自定义锁（不可重入锁）
 class MyLock implements Lock {
    class MySyns extends AbstractQueuedSynchronizer{
        @Override
        protected boolean tryAcquire(int arg) {
            if (compareAndSetState(0,1)){
//                加上了锁,并设置了owner为当前线程
                setExclusiveOwnerThread(Thread.currentThread());
                return true;
            }
            return false;
        }

        @Override
        protected boolean tryRelease(int arg) {

            setExclusiveOwnerThread(null);
            setState(0);
            return true;
        }

        @Override
        protected boolean isHeldExclusively() {
            return getState()==1;
        }
        public Condition newCondition(){
            return new ConditionObject();
        }
    }

    MySyns syns=new MySyns();
    @Override  //加锁（不成功进入队列等待）
    public void lock() {
        syns.acquire(1);

    }

    @Override  //加锁可打断
    public void lockInterruptibly() throws InterruptedException {
        syns.acquireInterruptibly(1);
    }

    @Override  //尝试加锁（一次）
    public boolean tryLock() {
        return syns.tryAcquire(1);
    }

    @Override //尝试加锁，带超时
    public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
        return syns.tryAcquireNanos(1,unit.toNanos(time));
    }

    @Override //解锁
    public void unlock() {
        syns.release(1);
    }

    @Override  //创建同步变量
    public Condition newCondition() {
        return syns.newCondition();
    }
}

