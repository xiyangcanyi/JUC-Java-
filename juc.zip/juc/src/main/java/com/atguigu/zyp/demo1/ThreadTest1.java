package com.atguigu.zyp.demo1;

import org.junit.Test;

/**
 * @author zyp
 * @create 2023-02-15 11:43
 */
public class ThreadTest1 {
    public static void main(String[] args) {
        // 获取cpu的核数
        // CPU 密集型，IO密集型
        System.out.println(Runtime.getRuntime().availableProcessors());
//        Thread


//        wait必须使用在同步代码块，会释放锁
//        sleep可以使用在任何地方，不会释放锁



    }
}
