package com.atguigu.zyp.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Predicate;

/**
 * @author zyp
 * @create 2023-02-16 20:59
 *
 * 题目 使用一行程序完成
 * * 有5个用户 筛选
 * * 1.ID必须为偶数
 * * 2.年龄必须大于23岁
 * * 3.用户名转为大写字母
 * * 4.用户名字母倒着排序
 * * 5.只输出一个用户
 *
 */
public class Test {
    public static void main(String[] args) {
        User u1 = new User(1,"a",21);
        User u2 = new User(2,"b",22);
        User u3 = new User(3,"c",23);
        User u4 = new User(4,"d",24);
        User u5 = new User(6,"e",25);
//      集合
        List<User> list = Arrays.asList(u1, u2, u3, u4, u5);
//        System.out.println(list);
//        ID必须为偶数


        // 计算交给Stream流
        // lambda表达式、链式编程、函数式接口、Stream流式计算
        list.stream().
                filter(user -> user.getId()%2==0).
                filter(user -> user.getAge()>23)
                .map(user -> user.getName().toUpperCase(Locale.ROOT))
                .sorted(((o1, o2) ->-o1.compareTo(o2)))
                .limit(1)
                .forEach(System.out::println);
//        年龄必须大于23



    }
}
