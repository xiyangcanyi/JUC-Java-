package com.atguigu.zyp.unsafe;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

/**并发修改异常
 * java.util.ConcurrentModificationException
 *
 * 1.Set<String> set = Collections.synchronizedSet(new HashSet<>());
 * 2. CopyOnWriteArraySet<String> set = new CopyOnWriteArraySet<>();
 *
 * @author zyp
 * @create 2023-02-16 10:07
 *
 *
 *
 */
public class SetTest {
    public static void main(String[] args) {
//        HashSet<String> set = new HashSet<>();
//        线程不安全解决方式一
//        Set<String> set = Collections.synchronizedSet(new HashSet<>());
//        线程不安全解决方式二
        CopyOnWriteArraySet<String> set = new CopyOnWriteArraySet<>();

        for (int i = 1; i <30 ; i++) {
            new Thread(()->{
                set.add(UUID.randomUUID().toString().substring(0,5));
                System.out.println(set);

            }).start();
        }
    }
}
