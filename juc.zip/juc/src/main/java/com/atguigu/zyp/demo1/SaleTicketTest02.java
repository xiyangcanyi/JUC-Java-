package com.atguigu.zyp.demo1;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author zyp
 * @create 2023-02-15 17:02
 */
public class SaleTicketTest02 {
    public static void main(String[] args) {
//        并发：多线程操作同一个资源类，把资源丢入线程
        Ticket2 t1 = new Ticket2();
        new Thread(() -> {
            for (int i = 1; i < 40; i++) {
                t1.sale();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }, "A").start();
        new Thread(() -> {
            for (int i = 1; i < 40; i++) {
                t1.sale();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, "B").start();
        new Thread(() -> {
            for (int i = 1; i < 40; i++) {
                t1.sale();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, "C").start();
//

    }

}
//资源类1

/*
Lock的步骤：
1.new ReetrantLock()
2.加锁
3.解锁


 */

    class Ticket2 {
        //    @Override
//    public void run() {
//
//    }
//        属性、方法
        private int number = 30;

//        公平锁：十分公平：可以先来后到
//        非公平锁：

        Lock lock=new ReentrantLock();
        //    卖票的方式
        public void sale() {
            lock.lock();
            try {
//                业务代码
                if (number > 0) {
                    System.out.println(Thread.currentThread().getName()
                            + "卖出了：" + (number--) + "号的" + "票，剩余：" + number);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                lock.unlock();
            }

        }


    }


