package com.atguigu.zyp.volatile1;

import java.util.concurrent.atomic.AtomicInteger;

import static java.lang.Thread.yield;

/**
 * @author zyp
 * @create 2023-02-17 10:50
 */
public class VolatileDemo02 {
//    private volatile static int num=0;
    private volatile static AtomicInteger num=new AtomicInteger();
    public static void add(){
//        num++;  //不是一个原子性操作
        num.getAndIncrement();//AtomicInteger():+1操作
    }
    public static void main(String[] args) {
//        理论上num的结果是2万
        for (int i = 0; i < 20; i++) {

            new Thread(()->{
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                for (int j = 0; j < 1000; j++) {
                    add();
                }
            }).start();
        }
        // 判断只要剩下的线程不大于2个，就说明20个创建的线程已经执行结束
        while (Thread.activeCount()>2){//main  gc
            // Java 默认有 main gc 2个线程
            yield();
        }
        System.out.println(Thread.currentThread().getName()+"-----"+num);//main-----19574 实际运行不到20000
    }
}
