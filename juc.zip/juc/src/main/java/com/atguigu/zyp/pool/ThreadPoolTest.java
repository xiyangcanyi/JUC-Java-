package com.atguigu.zyp.pool;

import java.util.concurrent.*;

/**
 * @author zyp
 * @create 2023-02-16 17:06
 * Executors 工具类、三大方法
 * 使用线程池之后，使用线程池创建线程
 *
 * 拒绝策略
 * new ThreadPoolExecutor.AbortPolicy()（默认的）//银行满了，还有人进来，不处理这个人，抛出异常
 * new ThreadPoolExecutor.CallerRunsPolicy()//哪来的去哪里main线程会执行
 * new ThreadPoolExecutor.DiscardPolicy()//队列满了，丢掉任务不会抛异常
 * new ThreadPoolExecutor.DiscardOldestPolicy()//队列满了，尝试去和最早的竞争，也不会抛出异常
 *
 *
 */
public class ThreadPoolTest {
    public static void main(String[] args) {
//        调用静态方法创建对象
//        ExecutorService threadPool = Executors.newSingleThreadExecutor();//单个线程固定的
//        ExecutorService threadPool= Executors.newFixedThreadPool(5);//创建一个固定的线程池的大小
//        ExecutorService threadPool= Executors.newCachedThreadPool();//可伸缩的，遇强则强，遇弱则弱
//      自定义现场迟迟！工作ThreadPoolExecutor

//        最大线程到底如何定义？
//        1.CPU密集型：几核，就是几，可以保持CPU效率最高
//        2.IO密集型：判断你程序中十分耗IO的线程,>
//                程序:15个大型任务,io(调优的)

//        获取CPU的核数
        System.out.println(Runtime.getRuntime().availableProcessors());
        ThreadPoolExecutor threadPool = new ThreadPoolExecutor(
                2,
                Runtime.getRuntime().availableProcessors(),
                3,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(3),//相当于银行的候客区
                Executors.defaultThreadFactory(),
                new ThreadPoolExecutor.DiscardOldestPolicy());//队列满了，尝试去和最早的竞争，也不会抛出异常


        try {
//            最大承载：Queue+max
//            超出最大承载，被拒绝 抛异常java.util.concurrent.RejectedExecutionException
            for (int i = 0; i < 9; i++) {

                threadPool.execute(()->{
                    System.out.println(Thread.currentThread().getName()+" ok111");
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //        线程池用完，程序结束，关闭线程
            threadPool.shutdown();
        }

    }
}
