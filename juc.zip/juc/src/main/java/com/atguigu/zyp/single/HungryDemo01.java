package com.atguigu.zyp.single;

/**
 * @author zyp
 * @create 2023-02-17 11:30
 */
public class HungryDemo01 {
//      可能会浪费空间
// 单例不安全，因为反射可以破坏单例，如下解决这个问题：
        private byte[] data1=new byte[1024*1024];
        private byte[] data2=new byte[1024*1024];
        private byte[] data3=new byte[1024*1024];
        private byte[] data4=new byte[1024*1024];

    private HungryDemo01(){

    }

    private static final HungryDemo01 HUNGRY_DEMO_01=new HungryDemo01();

    public static HungryDemo01 getInstance(){
        return HUNGRY_DEMO_01;
    }

}
