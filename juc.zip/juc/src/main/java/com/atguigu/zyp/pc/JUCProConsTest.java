package com.atguigu.zyp.pc;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author zyp
 * @create 2023-02-15 21:22
 *
 * Lock锁的方式和Condition实现线程安全
 *
 */
public class JUCProConsTest {
    public static void main(String[] args) {
        Data1 data = new Data1();
        new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                try {
                    data.increment();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }, "A").start();
        new Thread(() -> {
            for (int i = 0; i < 10; i++) {

                try {
                    data.decrement();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, "B").start();
        new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                try {
                    data.increment();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }, "C").start();
        new Thread(() -> {
            for (int i = 0; i < 10; i++) {

                try {
                    data.decrement();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, "D").start();

    }
}


//等待  业务  通知
class Data1 {  //数字资源类

    private int number = 0;
    Lock lock = new ReentrantLock();
    Condition condition = lock.newCondition();

    //            condition.await();
//            condition.signalAll();
    //    +1
    public void increment() {
//            Condition condition = lock.newCondition();
        lock.lock();
        try {

            while (number != 0) {
                //            等待
                condition.await();

            }
            number++;
            System.out.println(Thread.currentThread().getName() + "=>" + number);
//        通知其他线程我+1完毕了
            condition.signalAll();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }

    }

    //    -1
    public  void decrement() {
        lock.lock();
        try {
            while (number == 0) {
                condition.await();
            }
            number--;
            //        通知其他线程我-1完毕了
            condition.signal();
            System.out.println(Thread.currentThread().getName() + "=>" + number);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }

    }

}


