package com.atguigu.zyp.lock;

import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicStampedReference;

/**
 * @author zyp
 * @create 2023-02-17 15:39
 *
 * 自旋锁
 */

public class SpinLockDemo1 {

//    int 0;
//    Thread:Null
       AtomicReference<Thread> atomicReference=new AtomicReference<Thread>();
//

//    加锁
        public void myLock(){
            Thread thread = new Thread();
            System.out.println(Thread.currentThread().getName()+"==>lock");
            while (! atomicReference.compareAndSet(null,thread)){
//                System.out.println(Thread.currentThread().getName()+"在自旋");
            }
        }

//    解锁
    public void myUnLock(){
        Thread thread = new Thread();
        System.out.println(Thread.currentThread().getName()+"==>myUnlock");

        atomicReference.compareAndSet(thread,null);
    }



}
