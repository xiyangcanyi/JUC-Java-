package com.atguigu.zyp.function;

import java.util.function.Predicate;

/**
 * @author zyp
 * @create 2023-02-16 20:36
 *
 * 断定型接口:有一个输入参数,返回值只能是布尔值!
 */
public class Demo02 {
    public static void main(String[] args) {

//        判断自负串是否为空
//        Predicate<String> predicate = new Predicate<String>() {
//            @Override
//            public boolean test(String str) {
////                if (str != null && str.length() != 0) {
////                    return true;
////                }
//                return str.isEmpty();
//            }
//        };
        Predicate<String> predicate=str->str.isEmpty();
        System.out.println(predicate.test("abc"));
    }
}
