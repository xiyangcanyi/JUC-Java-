package com.atguigu.zyp.function;

import java.util.function.Supplier;

/**
 * @author zyp
 * @create 2023-02-16 20:49
 *
 * 供给型接口:没有输入,只有返回
 *
 */
public class Demo04 {
    public static void main(String[] args) {
//        Supplier<Integer> supplier = new Supplier<Integer>() {
//            @Override
//            public Integer get() {
//                System.out.println("get()");
//                return 1024;
//            }
//        };
        Supplier<Integer> supplier =()->{
            System.out.println("get()");
            return 1024;
        };
        System.out.println(supplier.get());
    }
}
