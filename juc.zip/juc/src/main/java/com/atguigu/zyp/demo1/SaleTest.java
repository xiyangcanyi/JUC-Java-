package com.atguigu.zyp.demo1;

/**
 * 基本的买票例子
 *
 * @author zyp
 * @create 2023-02-15 16:35
 */
/*
    真正的多线程开发，公司中的开发
    线程就是一个单独的资源，没有任何的附属操作


 */
public class SaleTest {
    public static void main(String[] args) {
//        并发：多线程操作同一个资源类，把资源丢入线程
        Ticket t1 = new Ticket();
//      @FunctionInterface  函数式接口：jdk1.8
//        new Thread(t1).start();
        new Thread(() -> {
            for (int i = 1; i < 60; i++) {
                t1.sale();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }, "A").start();
        new Thread(() -> {
            for (int i = 1; i < 60; i++) {
                t1.sale();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, "B").start();
        new Thread(() -> {
            for (int i = 1; i < 60; i++) {
                t1.sale();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, "C").start();


    }

}
//资源类
class Ticket {
    //    @Override
//    public void run() {
//
//    }
    private int number = 50;

    //    卖票的方式
    public synchronized void sale() {
        if (number > 0) {
            System.out.println(Thread.currentThread().getName()
                    + "卖出了：" + (number--) + "号的" + "票，剩余：" + number);
        }
    }


}
