package com.atguigu.zyp.rwLock;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * ReadWriterLock
 * @author zyp
 * @create 2023-02-16 12:48
 *
 * 独占锁：写锁 ：一次只能被一个线程占有
 * 共享锁：读锁 ：多个线程可以同时占有
 *
 * ReadWriteWriteLock
 *
 * 读--读：可以共存
 * 读--写：不能共存
 * 写--写：不能共存
 *
 *
 *
 *
 */
public class ReadWriteLockTest{
    public static void main(String[] args) {
//        MyCache myCache = new MyCache();
        MyCacheLock myCache = new MyCacheLock();

//        写入
        for (int i = 0; i < 5; i++) {
            final int temp=i;
            new Thread(()->{

                myCache.put(Integer.toString(temp),temp+"");
            },String.valueOf(i)).start();
        }
        //        读取
        for (int i = 0; i < 5; i++) {
            final int temp=i;
            new Thread(()->{
                myCache.get(Integer.toString(temp));
            },String.valueOf(i)).start();
        }
    }


}
        /*
        自定义缓存
         */
class MyCache{
    private volatile Map<String,Object> map=new HashMap<>();
//    存、写
    public void put(String key,String value){
        System.out.println(Thread.currentThread().getName()+"写入"+key);
        map.put(key,value);
        System.out.println(Thread.currentThread().getName()+"写入完成");
    }

//    取、读
    public void get(String key){
        System.out.println(Thread.currentThread().getName()+"读取key"+key);
        map.get(key);
        System.out.println(Thread.currentThread().getName()+"读取完成");

    }
}

//加锁的
class MyCacheLock{
    private volatile Map<String,Object> map=new HashMap<>();

    private ReentrantReadWriteLock readWriteLock=new ReentrantReadWriteLock();
    //    存、写入的时候只希望只有一个线程
    public void put(String key,String value){
        try {
            readWriteLock.writeLock().lock();
            System.out.println(Thread.currentThread().getName()+"写入"+key);
            map.put(key,value);
            System.out.println(Thread.currentThread().getName()+"写入完成");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.writeLock().unlock();
        }
    }

    //    取、读入的时候所有线程都可读
    public void get(String key){
        try {
            readWriteLock.readLock().lock();
            System.out.println(Thread.currentThread().getName()+"读取key"+key);
            map.get(key);
            System.out.println(Thread.currentThread().getName()+"读取完成");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.readLock().unlock();
        }


    }
}