package com.atguigu.zyp.add;

import org.junit.Test;

import java.util.concurrent.CountDownLatch;

/**
 * @author zyp
 * @create 2023-02-16 11:23
 *
 * 减法计数器： 实现调用几次线程后 再触发某一个任务
 *
 *原理：
 *
 *
 *
 * 每次有线程调用 countDown() 数量-1，假设计数器变为0，countDownLatch.await() 就会被唤醒，
 * 继续执行！
 *
 *
 */
public class CountDownLatchDemo {
    @Test
    public void test1() throws InterruptedException {
        //    总数是6
        CountDownLatch countDownLatch = new CountDownLatch(6);
        for (int i = 1; i <= 6; i++) {

            new Thread(()->{
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread().getName()+"get out");
                countDownLatch.countDown();//-1
            },String.valueOf(i)).start();
        }
//        countDownLatch.countDown();//-1
        countDownLatch.await();//等待计数器归零，然后再向下执行

        System.out.println("Closedoor");
    }
    
    
}
