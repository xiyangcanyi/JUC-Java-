package com.atguigu.zyp.future;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * @author zyp
 * @create 2023-02-16 21:52
 *
 * Future 设计的初衷： 对将来的某个事件的结果进行建模
 * <p>
 * 异步执行
 * 成功回调
 * 失败回调
 */
public class Demo01 {
    public static void main(String[] args) {
//        CompletableFuture completableFuture = CompletableFuture.runAsync(() -> {
//            try {
//                TimeUnit.SECONDS.sleep(2);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            System.out.println(Thread.currentThread().getName() + "runAsync=>Void");
//        });
//        System.out.println("11111");
//        completableFuture.get();
//        有返回值,异步回调
//        ajax  返回成功或者失败信息
//        返回错误信息
        CompletableFuture<Integer> completableFuture = CompletableFuture.supplyAsync(()->{
            System.out.println(Thread.currentThread().getName()+"completableFuture==>integer");
            int i=10/0;
            return 1024;
        });
        completableFuture.whenComplete((t,u)->{
            System.out.println("t=>"+t);
            System.out.println("u=>"+u);
        }).exceptionally(e->{
             e.printStackTrace();
            System.out.println(e.getMessage());
            return 342;//可以获取错误的返回结果
        });



    }
}
