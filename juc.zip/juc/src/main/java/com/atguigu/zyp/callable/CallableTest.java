package com.atguigu.zyp.callable;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * @author zyp
 * @create 2023-02-16 10:37
 *
 *
 * Callable 是 java.util 包下 concurrent 下的接口，有返回值，可以抛出被检查的异常
 * Runable 是 java.lang 包下的接口，没有返回值，不可以抛出被检查的异常
 * 二者调用的方法不同，run()/ call()
 * 同样的 Lock 和 Synchronized 二者的区别，前者是java.util 下的接口 后者是 java.lang 下的关键字
 *
 *
 *
 */
public class CallableTest {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
//        new Thread(new Runnable()).start();
//        new Thread(new FutureTask<V>()).start();
//        new Thread(new FutureTask<V>(Callable)).start();

        MyThread thread = new MyThread();

        FutureTask<String> futureTask = new FutureTask<>(thread);

        new Thread(futureTask,"A").start();
        new Thread(futureTask,"B").start();//结果会被缓冲，

        String s = futureTask.get();//获取Callable的返回结果,注意get（）方法可能会阻塞！一般把他
        // 放到最后（或者使用异步通信）
//
        System.out.println(s);


    }
}

class  MyThread implements Callable<String> {

    @Override
    public String call(){
        System.out.println("call()");
        return null;
    }
}
