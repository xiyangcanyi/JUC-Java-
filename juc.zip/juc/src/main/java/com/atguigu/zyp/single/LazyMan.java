package com.atguigu.zyp.single;

import java.lang.reflect.Constructor;

/**
 * @author zyp
 * @create 2023-02-17 11:33
 */
public class LazyMan {


    private LazyMan() {
//        System.out.println(Thread.currentThread().getName()+"ok");
        if (cbd==false){
            cbd=true;
        }else {
            throw new RuntimeException("不要试图使用反射破环异常");
        }
    }

    private volatile static LazyMan lazyMan;

    private static boolean cbd=false;
//    双重检测锁模式，懒汉式单例  DCL懒汉式
    public static LazyMan getInstance() {

        if (lazyMan==null){
            synchronized (LazyMan.class){
                if (lazyMan == null) {
                    lazyMan = new LazyMan();//不是一个原子性操作
                    /*
                    1.分配内存空间
                    2.执行构造方法，初始化对象
                    3.把这个对象指向这个空间

                    123
                    132 A
                        B  //此时lazyMan还没有完成构造

                    * */
                }
            }
        }
        return lazyMan;
    }

    //    多线程并发
    public static void main(String[] args) throws Exception {
//        for (int i = 0; i < 10; i++) {
//            new Thread(()->{
//                try {
//                    Thread.sleep(100);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                LazyMan.getInstance();
//            }).start();
//        }
        Constructor<LazyMan> declaredConstructor = (Constructor<LazyMan>) LazyMan.class.getDeclaredConstructor(null);
        declaredConstructor.setAccessible(true);
        LazyMan lazyMan = declaredConstructor.newInstance();
        LazyMan lazyMan1 = declaredConstructor.newInstance();

        System.out.println(lazyMan1);
        System.out.println(lazyMan);


    }
}
