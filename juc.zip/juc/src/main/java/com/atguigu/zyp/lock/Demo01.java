package com.atguigu.zyp.lock;

import java.util.concurrent.locks.ReentrantLock;

/**
 * @author zyp
 * @create 2023-02-17 15:12
 */
public class Demo01 {
    public static void main(String[] args) {
        // A---sms
        //A---call
        //B---call
        Phone phone = new Phone();
        new Thread(()->{
            phone.sms();
        },"A").start();


        new Thread(()->{
            phone.call();
        },"B").start();
    }
}

class Phone{

//    外面的锁
    public synchronized void sms(){


        try {
            System.out.println(Thread.currentThread().getName()+"---sms");
//        调用该方法时候进入了里面的锁
            call();//注意调用这个也有锁
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }
    }

    public synchronized void call(){

        try {
            System.out.println(Thread.currentThread().getName()+"---call");
        } finally {

        }
    }

}