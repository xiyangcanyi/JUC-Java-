package com.atguigu.zyp.unsafe;


import sun.plugin.util.UIUtil;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author zyp
 * @create 2023-02-16 10:18
 *
 * 1.Map<Object, Object> map = Collections.synchronizedMap(new HashMap<>());
 * 2. ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();
 *
 */
public class MapTest {
    //
    public static void main(String[] args) {
//        Map<String,String> map=new HashMap<>();
//        Map<String,String> map1=new HashMap<>();
//        Map<String,String> map3=new HashMap<>();
//        Map<Object, Object> map = Collections.synchronizedMap(new HashMap<>());
        ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();
        for (int i = 1; i < 30; i++) {
            new Thread(()->{
                map.put(Thread.currentThread().getName(), UUID.randomUUID().toString().substring(0,5));
                System.out.println(map);
            }).start();
        }

    }
}
