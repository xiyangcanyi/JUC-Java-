package com.atguigu.zyp.lock8;

import java.util.concurrent.TimeUnit;

/**
 * @author zyp
 * @create 2023-02-15 22:05
 *
 * 7、1个静态的同步方法，1个普通的同步方法 ，一个对象，先打印 发短信？打电话？
 *  * 8、1个静态的同步方法，1个普通的同步方法 ，两个对象，先打印 发短信？打电话？
 *
 *
// 7/8 两种情况下，都是先执行打电话,后执行发短信,因为二者锁的对象不同,
// 静态同步方法锁的是Class类模板,普通同步方法锁的是实例化的对象,
// 所以不用等待前者解锁后 后者才能执行,而是两者并行执行,因为发短信休眠4s
// 所以打电话先执行。

 */
public class Test4 {

    public static void main(String[] args) {
//        两个对象的Class对象唯一 static 锁的是Class
//        **不同实例对象的Class类模板只有一个，static静态的同步方法，锁的是Class **
        Phone4 phone = new Phone4();
        Phone4 phone1 = new Phone4();

        new Thread(()->{
            phone.sendSms();
        },"A").start();
//        发短信还是打电话（捕获）
        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        new Thread(()->{
            phone.call();
        }).start();

//        new Thread(()->{
//            phone.hello();
//        },"C").start();


    }


}
//phone唯一的一个Class对象
class  Phone4{
//   静态的同步方法
    public static synchronized void sendSms(){
        try {
            TimeUnit.SECONDS.sleep(4);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("发短信");
    }
    public  void call(){
        System.out.println("打电话");
    }
}
// 先执行发短信，后执行打电话