package com.atguigu.zyp.cas;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicStampedReference;

/**
 * @author zyp
 * @create 2023-02-17 14:12
 */
public class CASDemo {
//    CAS compareAndSet :比较并交换
    public static void main(String[] args) {

//        AtomicInteger atomicInteger = new AtomicInteger(2020);
        /*
//        对于我们平时写的SQL：乐观锁!
        CAS:比较并交换
        * */
//        期望、更新（乐观锁）,如果我的期望达到了，那么就更新，否则就不更新

//        ==============捣乱的线程+++++++++++++++++++++++
//        System.out.println(atomicInteger.compareAndSet(2020, 2021));//true
//        System.out.println(atomicInteger.get());//2021
//
//        System.out.println(atomicInteger.compareAndSet(2021, 2020));//false
//        System.out.println(atomicInteger.get());//2021
//
//
////        ++++++++++++++++期待的线程==============
//        System.out.println(atomicInteger.compareAndSet(2020, 6666));//false
//        System.out.println(atomicInteger.get());//

//        原子引用 Integer（-128-127） 注意如果泛型是一个包装类，注意对象的引用问题
        AtomicStampedReference<Integer> atomicStampedReference =
                new AtomicStampedReference<>(123, 1);
        new Thread(()->{
            int stamp = atomicStampedReference.getStamp();//获得版本号
            System.out.println("A1=>"+stamp);


            try {
                TimeUnit.SECONDS.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(atomicStampedReference.compareAndSet(123, 124,
                    atomicStampedReference.getStamp(), atomicStampedReference.getStamp() + 1));
            System.out.println("A2->"+atomicStampedReference.getStamp());

            System.out.println(atomicStampedReference.compareAndSet(124, 123,
                    atomicStampedReference.getStamp(), atomicStampedReference.getStamp() + 1));
            System.out.println("A3->"+atomicStampedReference.getStamp());
        },"a").start();
        new Thread(()->{
            int stamp = atomicStampedReference.getStamp();
            System.out.println("B1=>"+stamp);
            try {
                TimeUnit.SECONDS.sleep(4);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(atomicStampedReference.compareAndSet(123, 66,
                    stamp, stamp + 1));
            System.out.println("B2=>"+atomicStampedReference.getStamp());

        },"b").start();

    }
}
