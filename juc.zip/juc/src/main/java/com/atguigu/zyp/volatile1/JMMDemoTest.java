package com.atguigu.zyp.volatile1;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author zyp
 * @create 2023-02-17 9:45
 */
public class JMMDemoTest {
    //    不加volatile程序就会死循环
//    变成原子类的Integer
    private volatile static int number=0;


    public static void main(String[] args) {

        new Thread(() -> {
            while (number == 0) {//线程1对于主内存的变换不知道的

            }
        }).start();
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        number = 1;
        System.out.println(number);
    }
}
