package com.atguigu.zyp.function;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * @author zyp
 * @create 2023-02-16 20:44
 *
 * 消费者接口:Consumer:只有输入,没有返回值
 * 供给型接口:
 *
 */
public class Demo03 {
    public static void main(String[] args) {

//        Consumer<String> consumer = new Consumer<String>() {
//            @Override
//            public void accept(String s) {
//                System.out.println(s);
//            }
//        };
        Consumer<String> consumer=s->{
            System.out.println(s);
        };
        consumer.accept("ssss");
    }
}
